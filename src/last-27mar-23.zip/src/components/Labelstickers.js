import React from 'react'

const Labelstickers = () => {

  return (
<>
    <div className="page-heading">
    <h1>Labels & Stickers</h1>
    </div>
    <section className='text-center'>
    <div className='container'>
        <h2>This is Labelstickers Page </h2>

    </div>
 </section>
 </>
  )
}
export default Labelstickers