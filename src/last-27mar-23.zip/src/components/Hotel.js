import React from 'react'

export const Hotel = () => {
  return (

    <section className='text-center'>
    <div className='container'>
        <h2>Hotel / Flight </h2>

        </div>
</section>

  )
}

export default Hotel;