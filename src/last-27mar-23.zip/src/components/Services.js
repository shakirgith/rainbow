import React from 'react'

export const Services = () => {
  return (
    <>
          <div className="page-heading">
              <h1>Services</h1>
          </div>

       <section className="text-center m-0">
          <div className="container">
         
          </div>
        </section>
    </>
  )
}
