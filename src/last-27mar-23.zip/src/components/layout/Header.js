import { React, useState, useEffect, useContext } from "react";
import { NavLink, useLocation, useNavigate } from "react-router-dom";
import { userContext } from "../contexts/";
import { MetaTitle, MetaDescription } from "../Meta";

const Header = () => {
  // const [openMenu, setOpenMenu] = useState(false);
  const [isActive, setIsActive] = useState(false);
  const { pathname } = useLocation();
  const { user, setUser } = useContext(userContext);

  let navigate = useNavigate();

  const LogOut = () => {
    // localStorage.removeItem("email");
    // localStorage.clear();
    // setLoading(true);
    // navigate(`/signin`);
    setUser({});
  };

  //  useEffect(() => {
  //   console.log(count1,count2)
  // }, [])

  useEffect(() => {
    window.scrollTo(0, 0);
    //console.log(pathname)

    MetaTitle(
      pathname === "/"
        ? "Home Page Title"
        : pathname === "/about"
        ? "About New Page Title"
        : pathname === "/contact"
        ? "Contact us New Page Title"
        : pathname === "/hook"
        ? "Hook Page Title"
        : pathname === "/signin"
        ? "Login Page"
        : pathname === "/register"
        ? "Register Page"
        : pathname === "/profile"
        ? "Welcome To My Website {user}"
        : "Unknown Title"
    );
    MetaDescription(
      pathname === "/"
        ? "Home Page Description"
        : pathname === "/about"
        ? "About New Page Description"
        : pathname === "/hook"
        ? "Hook Page Description"
        : pathname === "/contact"
        ? "Contactus New Page Description"
        : pathname === "/signin"
        ? "This is Login Page"
        : pathname === "/register"
        ? "Register Page"
        : pathname === "/profile"
        ? "Welcome To My Website"
        : "Unknown Description"
    );
  }, [pathname]);

  const handleClick = (event) => {
    setIsActive((current) => !current);
  };

  // useEffect(() =>  {
  //   document.addEventListener("mousedown", () => {
  //     setIsActive(false)
  //   });

  // });

  // Sticky Menu Area
  useEffect(() => {
    window.addEventListener("scroll", isSticky);
    return () => {
      window.removeEventListener("scroll", isSticky);
    };
  });

  const isSticky = (e) => {
    const header = document.querySelector(".header-menu");
    const scrollTop = window.scrollY;
    scrollTop >= 250
      ? header.classList.add("is-sticky")
      : header.classList.remove("is-sticky");
  };

  return (
    <>
     
 <header className="header">
  <nav className="header-menu navbar style-one navbar-area navbar-expand-lg py-20"> 

      <div className="topbar">
        <div class="container container-1570">
          <div className="tobar-content">
            <div class="topbar-left text-lg-start text-center">
              <span class="off">20% OFF</span>
              <span> Free Shipping on all U.S. Orders $50+</span>
            </div>

            <div className="navbar style-one navbar-area topbar-menu">
              <div className="navbar-collapse">
                <ul className="navbar-nav menu-open text-lg-end">
                  <li>
                    <NavLink activeClassName="active" to="/help">
                      Customer Support
                    </NavLink>
                  </li>

                  {/* 
                  <li class="dropdown">
                  <NavLink class="btn btn-secondary dropdown-toggle" to="" role="button" id="dropdownMenuLink" data-bs-toggle="dropdown" aria-expanded="false">
                    Dropdown link
                  </NavLink>

                  <ul class="dropdown-menu" aria-labelledby="dropdownMenuButton1">
                    <li><a class="dropdown-item" href="#">Action</a></li>
                    <li><a class="dropdown-item" href="#">Another action</a></li>
                    <li><a class="dropdown-item" href="#">Something else here</a></li>
                  </ul>
                </li> */}

                  <li>
                    <NavLink activeClassName="active" to="/contact">
                      Contact
                    </NavLink>
                  </li>

                  {user.fname ? (
                    <>
                      <li class="menu-item-has-children">
                        <NavLink className="guest" to="">
                          <i className="far fa-user me-2"></i>
                          <span className="me-0">{user.fname} </span>
                        </NavLink>

                        <ul class="sub-menu">
                          <li>
                            <NavLink to="/profile">My Account</NavLink>
                          </li>
                          <li>
                            <NavLink to="" onClick={LogOut}>
                              Logout
                            </NavLink>
                          </li>
                        </ul>
                      </li>
                    </>
                  ) : (
                    <>
                      <li>
                        <NavLink to="/signin">
                          <button className="btn p-0">Login / Signup</button>
                        </NavLink>
                      </li>
                    </>
                  )}
                </ul>
              </div>
            </div>
          </div>
        </div>
      </div>




      {/* <nav className="header-menu navbar style-one navbar-area navbar-expand-lg py-20"> */}

        <div class="container container-1570">
          <div class="responsive-mobile-menu">
            <button
              className={`menu toggle-btn d-block d-lg-none ${
                isActive ? "active" : ""
              }`}
              data-target="#Iitechie_main_menu"
              onClick={handleClick}
              aria-expanded="false"
              aria-label="Toggle navigation"
            >
              <span class="icon-left"></span>
              <span class="icon-right"></span>
            </button>
          </div>
          <div class="logo">
            <NavLink className="navbar-brand" to="/">
              <img
                className="img-fluid"
                src={"assets/images/trp-logo.png"}
                alt="logo"
              />
            </NavLink>
          </div>

          <div class="nav-right-part nav-right-part-mobile">
            <button class="search-bar-btn" href="#">
              <i class="fas fa-search"></i>
            </button>
          </div>

          <div
            id="Iitechie_main_menu"
            className={`collapse navbar-collapse ${isActive ? "active" : ""}`}
          >
            <ul className="navbar-nav menu-open text-lg-end">
              <li>
                <NavLink
                  activeClassName="active"
                  aria-current="page"
                  to="/"
                  onClick={handleClick}
                >
                  Home
                </NavLink>
              </li>

              <li>
                <NavLink
                  activeClassName="active"
                  to="/graphicdesign"
                  onClick={handleClick}
                >
                  Graphic Design & Printing
                </NavLink>
              </li>

              <li className="menu-item-has-children">
                <NavLink
                  activeClassName="active"
                  to="/about"
                  onClick={handleClick}
                >
                  Categories
                </NavLink>

             

                <div className="dropdown-megamenu sub-menu">
                        <div className="list-group list-group-flush">
                          <h7 className="mega-menu-heading">All Categories</h7>

                          <ul className="menu-list-group">
                            <li className="list-group-item">
                              <NavLink
                                className="list-group-item-action"
                                activeClassName="active"
                                to="/about"
                                onClick={handleClick}
                              >
                                Book Printing
                              </NavLink>
                            </li>

                            <li className="list-group-item">
                              <NavLink
                                className="list-group-item-action"
                                activeClassName="active"
                                to="/about"
                                onClick={handleClick}
                              >
                                Book Printing
                              </NavLink>
                            </li>

                            <li className="list-group-item">
                              <NavLink
                                className="list-group-item-action"
                                activeClassName="active"
                                to="/about"
                                onClick={handleClick}
                              >
                                Brochure Printing
                              </NavLink>
                            </li>

                            <li className="list-group-item">
                              <NavLink
                                className="list-group-item-action"
                                activeClassName="active"
                                to="/about"
                                onClick={handleClick}
                              >
                                Business Card
                              </NavLink>
                            </li>

                            <li className="list-group-item">
                              <NavLink
                                className="list-group-item-action"
                                activeClassName="active"
                                to="/about"
                                onClick={handleClick}
                              >
                                Catalogue Printing
                              </NavLink>
                            </li>

                            <li className="list-group-item">
                              <NavLink
                                className="list-group-item-action"
                                activeClassName="active"
                                to="/about"
                                onClick={handleClick}
                              >
                                Flyer Printing
                              </NavLink>
                            </li>

                            <li className="list-group-item">
                              <NavLink
                                className="list-group-item-action"
                                activeClassName="active"
                                to="/about"
                                onClick={handleClick}
                              >
                                Folder Printing
                              </NavLink>
                            </li>

                            <li className="list-group-item">
                              <NavLink
                                className="list-group-item-action"
                                activeClassName="active"
                                to="/about"
                                onClick={handleClick}
                              >
                                Hamper Box
                              </NavLink>
                            </li>

                            <li className="list-group-item">
                              <NavLink
                                className="list-group-item-action"
                                activeClassName="active"
                                to="/about"
                                onClick={handleClick}
                              >
                                Hang/Product Printing
                              </NavLink>
                            </li>

                            <li className="list-group-item">
                              <NavLink
                                className="list-group-item-action"
                                activeClassName="active"
                                to="/about"
                                onClick={handleClick}
                              >
                                Invitation Card Printing
                              </NavLink>
                            </li>

                            <li className="list-group-item">
                              <NavLink
                                className="list-group-item-action"
                                activeClassName="active"
                                to="/about"
                                onClick={handleClick}
                              >
                                Letterhead Printing
                              </NavLink>
                            </li>

                            <li className="list-group-item">
                              <NavLink
                                className="list-group-item-action"
                                activeClassName="active"
                                to="/about"
                                onClick={handleClick}
                              >
                                Magazine Printing
                              </NavLink>
                            </li>

                            <li className="list-group-item">
                              <NavLink
                                className="list-group-item-action"
                                activeClassName="active"
                                to="/about"
                                onClick={handleClick}
                              >
                                Newsletter Printing
                              </NavLink>
                            </li>

                            <li className="list-group-item">
                              <NavLink
                                className="list-group-item-action"
                                activeClassName="active"
                                to="/about"
                                onClick={handleClick}
                              >
                                Digital Printing
                              </NavLink>
                            </li>

                            <li className="list-group-item">
                              <NavLink
                                className="list-group-item-action"
                                activeClassName="active"
                                to="/about"
                                onClick={handleClick}
                              >
                                Offset Printing
                              </NavLink>
                            </li>

                            <li className="list-group-item">
                              <NavLink
                                className="list-group-item-action"
                                activeClassName="active"
                                to="/about"
                                onClick={handleClick}
                              >
                                Poster Printing
                              </NavLink>
                            </li>

                            <li className="list-group-item">
                              <NavLink
                                className="list-group-item-action"
                                activeClassName="active"
                                to="/about"
                                onClick={handleClick}
                              >
                                Digital Printing
                              </NavLink>
                            </li>

                            <li className="list-group-item">
                              <NavLink
                                className="list-group-item-action"
                                activeClassName="active"
                                to="/about"
                                onClick={handleClick}
                              >
                                Printing & Packaging
                              </NavLink>
                            </li>

                            <li className="list-group-item">
                              <NavLink
                                className="list-group-item-action"
                                activeClassName="active"
                                to="/about"
                                onClick={handleClick}
                              >
                                Prospectus Printing
                              </NavLink>
                            </li>

                            <li className="list-group-item">
                              <NavLink
                                className="list-group-item-action"
                                activeClassName="active"
                                to="/about"
                                onClick={handleClick}
                              >
                                Visiting Card Printing
                              </NavLink>
                            </li>

                            <li className="list-group-item">
                              <NavLink
                                className="list-group-item-action"
                                activeClassName="active"
                                to="/about"
                                onClick={handleClick}
                              >
                                Wall/Table Calendar <br /> Printing
                              </NavLink>
                            </li>

                            <li className="list-group-item">
                              <NavLink
                                className="list-group-item-action"
                                activeClassName="active"
                                to="/about"
                                onClick={handleClick}
                              >
                                Wedding Gift
                              </NavLink>
                            </li>

                            <li className="list-group-item">
                              <NavLink
                                className="list-group-item-action"
                                activeClassName="active"
                                to="/about"
                                onClick={handleClick}
                              >
                                T-shirt Printing
                              </NavLink>
                            </li>
                          </ul>
                        </div>
                      </div>
              </li>

           

              <li class="menu-item-has-children">
                <NavLink
                  activeClassName="active"
                  to="/stetionery"
                  onClick={handleClick}
                >
                  {" "}
                  Stationery
                </NavLink>

                <ul class="sub-menu">
                  <li>
                    <NavLink
                      activeClassName="active"
                      to="/stetionery"
                      onClick={handleClick}
                    >
                      Business Cards
                    </NavLink>
                  </li>

                  <li>
                    <NavLink
                      activeClassName="active"
                      to="/stetionery"
                      onClick={handleClick}
                    >
                      Business Cards
                    </NavLink>
                  </li>

                  <li>
                    <NavLink
                      activeClassName="active"
                      to="/stetionery"
                      onClick={handleClick}
                    >
                      Letterheads
                    </NavLink>
                  </li>

                  <li>
                    <NavLink
                      activeClassName="active"
                      to="/stetionery"
                      onClick={handleClick}
                    >
                      Envelopes
                    </NavLink>
                  </li>

                  <li>
                    <NavLink
                      activeClassName="active"
                      to="/stetionery"
                      onClick={handleClick}
                    >
                      Bill Book / Invoice
                    </NavLink>
                  </li>

                  <li>
                    <NavLink
                      activeClassName="active"
                      to="/stetionery"
                      onClick={handleClick}
                    >
                      Notebook / Diaries
                    </NavLink>
                  </li>

                  <li>
                    <NavLink
                      activeClassName="active"
                      to="/stetionery"
                      onClick={handleClick}
                    >
                      ID Cards
                    </NavLink>
                  </li>

                  <li>
                    <NavLink
                      activeClassName="active"
                      to="/stetionery"
                      onClick={handleClick}
                    >
                      Lanyards / Ribbon
                    </NavLink>
                  </li>
                </ul>
              </li>

              <li class="menu-item-has-children">
                <NavLink
                  activeClassName="active"
                  to="/labelstickers"
                  onClick={handleClick}
                >
                  Labels & Stickers
                </NavLink>

                <ul class="sub-menu">
                  <li>
                    <NavLink
                      activeClassName="active"
                      to="/labelstickers"
                      onClick={handleClick}
                    >
                      Business Cards
                    </NavLink>
                  </li>

                  <li>
                    <NavLink
                      activeClassName="active"
                      to="/labelstickers"
                      onClick={handleClick}
                    >
                      Letterheads
                    </NavLink>
                  </li>

                  <li>
                    <NavLink
                      activeClassName="active"
                      to="/labelstickers"
                      onClick={handleClick}
                    >
                      Envelopes
                    </NavLink>
                  </li>

                  <li>
                    <NavLink
                      activeClassName="active"
                      to="/labelstickers"
                      onClick={handleClick}
                    >
                      Bill Book / Invoice
                    </NavLink>
                  </li>

                  <li>
                    <NavLink
                      activeClassName="active"
                      to="/labelstickers"
                      onClick={handleClick}
                    >
                      Notebook / Diaries
                    </NavLink>
                  </li>

                  <li>
                    <NavLink
                      activeClassName="active"
                      to="/labelstickers"
                      onClick={handleClick}
                    >
                      ID Cards
                    </NavLink>
                  </li>

                  <li>
                    <NavLink
                      activeClassName="active"
                      to="/labelstickers"
                      onClick={handleClick}
                    >
                      Lanyards / Ribbon
                    </NavLink>
                  </li>
                </ul>
              </li>

              <li>
                <NavLink
                  activeClassName="active"
                  to="/services"
                  onClick={handleClick}
                >
                  Services
                </NavLink>
              </li>

              {/* <li className="nav-item dropdown">
                <NavLink
                  className="nav-link dropdown-toggle"
                  activeClassName="active"
                  id="dropdownMenuButton"
                  data-mdb-toggle="dropdown"
                  aria-expanded="false"
                  to="/about"
                >
                   Dropdown button
                </NavLink>

                <ul class="dropdown-menu" aria-labelledby="dropdownMenuButton">
                <li>
                <NavLink
                  className="dropdown-item"
                  activeClassName="active"
                  to="/about"
                  onClick={handleClick}
                >
                  Visiting Card
                </NavLink>
                </li>

                <li>
                <NavLink
                  className="dropdown-item"
                  activeClassName="active"
                  to="/about"
                  onClick={handleClick}
                >
                  Wedding Card
                </NavLink>
                </li>
               
              </ul>
              </li> */}

              {/* <li className="nav-item">
                <NavLink
                  className="nav-link"
                  activeClassName="active"
                  to="/fatchapi"
                  onClick={handleClick}
                >
                  Get Fatch API
                </NavLink>
              </li> */}

              {/* <li className="nav-item d-none">
                <NavLink
                  className="nav-link"
                  activeClassName="active"
                  to="/hook"
                  onClick={handleClick}
                >
                  Child Counter
                </NavLink>
              </li>

              <li className="nav-item d-none">
                <NavLink
                  className="nav-link"
                  activeClassName="active"
                  to="/hotel"
                  onClick={handleClick}
                >
                  Hotel/Flight
                </NavLink>
              </li>

              <li className="nav-item d-none">
                <NavLink
                  className="nav-link"
                  activeClassName="active"
                  to="/mycounter"
                  onClick={handleClick}
                >
                  My Counter
                </NavLink>
              </li> */}
            </ul>
          </div>

          <div className="nav-right-part nav-right-part-desktop">
            {/* <button className="search-bar-btn">
              <i class="fas fa-search"></i>
            </button> */}
            {/* <button>
              <i class="fas fa-shopping-basket"></i>
            </button>
            <button>
            flaticon-award
              <i class="fas fa-heart"></i>
            </button> */}
             <button className="search-bar-btn">
            <i class="fa-brands fa-whatsapp fa-2x"></i>
            </button> 
            <NavLink
              className="btn my-button theme-btn"
              activeClassName="active"
              to="/contact"
            >
              Order Now <i class="fas fa-long-arrow-right"></i>
            </NavLink>

            {/* <div class="menu-sidebar">
              <button>
                <i class="fas fa-ellipsis-h"></i>
                <i class="fas fa-ellipsis-h"></i>
                <i class="fas fa-ellipsis-h"></i>
              </button>
            </div> */}
          </div>
        </div>
      </nav>
      </header>
    </>
  );
};

export default Header;
