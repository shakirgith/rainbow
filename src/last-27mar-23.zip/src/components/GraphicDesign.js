import React from 'react'

const GraphicDesign = () => {

  return (
<>
    <div className="page-heading">
    <h1>Graphics Design & Printing</h1>
    </div>
    <section className='text-center'>
    <div className='container'>
        <h2>This is design Page </h2>

    </div>
 </section>
 </>
  )
}
export default GraphicDesign